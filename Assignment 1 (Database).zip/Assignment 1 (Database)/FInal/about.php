<?php
// Things to notice:
// This is an empty page where you can provide a simple overview and description of your site
// Consider it the 'welcome' page for your survey web site

// execute the header script:
require_once "header.php";

echo "<h3>Static Survey Website</h3><br> 
	 A brief survey of students to look into the the degree they've chosen and the reasons why";

// finish of the HTML for this page:
require_once "footer.php";

?>